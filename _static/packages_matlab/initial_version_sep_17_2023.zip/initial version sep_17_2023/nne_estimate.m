
function par = nne_estimate(net, prior, Y, Xp, Xa, Xc, consumer_idx, varargin)

opt = inputParser;
% addParameter(opt, 'refine', false);
addParameter(opt, 'se', false);
addParameter(opt, 'checks', true);
parse(opt, varargin{:});

warning('off', 'backtrace')

numType = class(prior.mid(0,0,0));
Xp = cast(Xp, numType);
Xa = cast(Xa, numType);
Xc = cast(Xc, numType);

n = size(Xc, 1);
J = size(Xp, 1)/n;

R = 50;

%% pre-estimation checks

if opt.Results.checks
    
    if size(Xp,2) < 2; warning("- Xp has fewer attributes than preset."); end
    if size(Xp,2) >  nnz(count(prior.name, '\beta'));  warning("- Xp has more attributes than preset."); end
    if size(Xa,2) >= nnz(count(prior.name, '\alpha')); warning("- Xa has more attributes than preset."); end
    if size(Xc,2) >= nnz(count(prior.name, '\eta'));   warning("- Xc has more attributes than preset."); end
        
    if n < prior.n_min; warning("- sample size n is too small: " + n); end
    if J < prior.J_min || J > prior.J_max; warning("- number of options J is outside trained range: " + J); end

    if mod(J,1) ~= 0; error('- number of available options is not same across consumers.'); end
    if ~isequal(consumer_idx, reshape(repmat(1:n,J,1), n*J, 1)); error('- consumer_idx is not correct.'); end
    
    [buy_rate, srh_rate, num_srh] = search_stat(Y, consumer_idx);

    if max(yb_t) > 1; error("- someone bought more than one options."); end
    if min(ys_t) < 1; error("- someone did not make the free search."); end
    if any(yb & ~ys); error("- someone bought an option without searching it."); end
 
    if buy_rate < 5e-3; warning("- buy rate is very small: " + buy_rate); end
    if buy_rate > 0.50; warning("- buy rate is very large: " + buy_rate); end
    
    if srh_rate < 0.01; warning("- search rate (non-free) is very small: " + srh_rate); end
    if srh_rate > 0.70; warning("- search rate (non-free) is very large: " + srh_rate); end
    
    if num_srh < 1.01; warning("- avg number of searches is very small: " + num_srh); end
    if num_srh > 4.00; warning("- avg number of searches is very large: " + num_srh); end
    
    Zp = zscore(Xp); 
    Za = zscore(Xa);
    Zc = zscore(Xc);
    
    Z = [Zp, Za, Zc(consumer_idx,:)];

    if any( abs(Z) > 3); warning('- X has extreme values.'); end

    p_min = mean( Z==min(Z));
    p_max = mean( Z==max(Z));
    binary = p_min + p_max > 0.99;

    if any(   binary & p_min < 0.05 | p_min > 0.95); warning('- X has highly unbalanced dummy variables.'); end
    if any( ~ binary & abs(skewness(Z)) > 2.5); warning('- X has highly skewed attributes.'); end

    Zp_t = accumatrix(consumer_idx, Zp)/J;
    Za_t = accumatrix(consumer_idx, Za)/J;

    if any( std(Zp - Zp_t(consumer_idx,:)) < 0.01); warning('- Xp lacks variations within consumers.'); end
    if any( std(Za - Za_t(consumer_idx,:)) < 0.01); warning('- Xa lacks variations within consumers.'); end
    if any( std(Za - Zp/(Zp'*Zp)*(Zp'*Za)) < 0.01); warning('- Xa essentially enters utility.'); end
    
end

%% estimation

[par, theta, mmt] = Estimate(net, prior, Y, Xp, Xa, Xc, consumer_idx);

%% post-estimation checks

if opt.Results.checks
    
    dist = abs(theta.val(:,1) - theta.mid);
    if any( dist > 2.5*theta.std); warning('- estimates are outside the usual parameter range in training.'); end

    if any( mmt < prior.mmt_q{1} | mmt > prior.mmt_q{2}); warning('- data moments have extreme values.'); end
    
    % theta.val
    diff_pooled = mean(range(theta.val,2).*theta.diff_w);
    if diff_pooled > max(prior.diff_q); warning('- pNNE is likely extrapolating.'); end
    
end

%% bootstrap SE and refinement

if opt.Results.se
    
    VAL = cell(1, R);
    
    parfor r = 1:R
        
        seed = RandStream('threefry');
        seed.Substream = r;
        
        k = randsample(seed, n, n, true);
        i = reshape((k'-1)*J + (1:J)', n*J, 1);
        
        par_boot = Estimate(net, prior, Y(i,:), Xp(i,:), Xa(i,:), Xc(k,:), consumer_idx);
        
        VAL{r} = par_boot.val;
        
    end

    par.se = std(cell2mat(VAL), [], 2);

end

warning('on', 'backtrace')

end

%% ................................................................................................
%% ................................................................................................

%% Large data splitter

function [par, theta, mmt] = Estimate(net, prior, Y, Xp, Xa, Xc, consumer_idx)

n = size(Xc, 1);

if n <= prior.n_max
    
    [par, theta, mmt] = Estimator(net, prior, Y, Xp, Xa, Xc, consumer_idx);
    
else

    T = ceil(n/prior.n_max);
    
    seed = RandStream('twister');
    subsample_idx = randi(seed, T, n, 1);
    
    Bin = cell(T, 4);
    
    for t = 1:T
        
        k = find( subsample_idx == t);
        i = ismember(consumer_idx, k);
        
        [par, theta, mmt] = Estimator(net, prior, Y(i,:), Xp(i,:), Xa(i,:), Xc(k,:), consumer_idx(i));
        
        Bin(t,:)  = {mmt, par.val, theta.val};
        
    end
    
    mmt       = mean(cell2mat(Bin(:,1) ));
    par.val   = mean(cell2mat(Bin(:,2)'), 2);
    theta.val = mean(cat(3, Bin{:,3}), 3);

end

end


%% Core estimation routine

function [par, theta, mmt] = Estimator(net, prior, Y, Xp, Xa, Xc, consumer_idx)

Zp = zscore(Xp);
Za = zscore(Xa);
Zc = zscore(Xc);

p = size(Xp, 2);
a = size(Xa, 2);
c = size(Xc, 2);

dummy = prior.num2dmy(p,a,c);

mmt = moments(Y, Zp, Za, Zc, consumer_idx, prior);
mmt_clip = min(prior.mmt_q{2}, max(prior.mmt_q{1}, mmt));

pred_net = predict(net.net, mmt_clip, exec='cpu');

pred_tree = arrayfun(@(k)predict(net.tree{k}, mmt_clip), 1:numel(net.tree), 'uni', false);
pred_tree = cell2mat(pred_tree);

theta = table();

theta.name = prior.name;
theta.val  = [pred_net', pred_tree'];

theta.mid = prior.mid(p,a,c);
theta.std = prior.std(p,a,c);
theta.diff_w = prior.diff_w;

theta = theta(dummy,:);

diff_pooled = mean(range(theta.val,2).*theta.diff_w);
coef = rescale(diff_pooled, "inputmin", prior.diff_q(1), "inputmax", prior.diff_q(2));

theta.val = [theta.val*[1-coef, coef]', theta.val];

alpha0 = theta.val(1                 , 1);
alpha  = theta.val(2       : a+1     , 1);
eta0   = theta.val(a+2               , 1);
eta    = theta.val(a+3     : a+c+2   , 1);
beta   = theta.val(a+c+3   : a+c+p+2 , 1);
% delta  = theta.val(a+c+p+3           , 1);

par = table();

par.name = theta.name;
par.val = [
           alpha0 - sum(alpha./std(Xa)'.*mean(Xa)')
           alpha./std(Xa)'
           eta0   - sum(eta  ./std(Xc)'.*mean(Xc)') + sum(beta ./std(Xp)'.*mean(Xp)')
           eta  ./std(Xc)'
           beta ./std(Xp)'
%            delta
           ];

end
